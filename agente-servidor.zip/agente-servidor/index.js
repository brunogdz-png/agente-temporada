const express = require("express");
const fetch = require("node-fetch");
const app = express();
app.use(express.json());

// ==============================
// CONFIGURAÇÕES DA SUA CASA
// (edite aqui com seus dados reais)
// ==============================
const CONFIG = {
  nomeCasa: "Casa Beira-Mar",
  localizacao: "Praia de Guarajuba, BA",
  descricao: "Casa com 4 quartos, 3 banheiros, piscina, churrasqueira e acesso direto à praia.",
  capacidade: "10 pessoas",
  checkIn: "14h",
  checkOut: "12h",
  minDiarias: 3,
  contato: "21980090609",
  regras: "Não é permitido fumar dentro da casa. Animais de estimação não são aceitos. Festas com som alto somente até 22h.",
  periodos: [
    { nome: "Réveillon 2026", inicio: "28/12/2025", fim: "02/01/2026", valor: 2800, minDiarias: 5 },
    { nome: "Carnaval 2026", inicio: "28/02/2026", fim: "05/03/2026", valor: 2200, minDiarias: 4 },
    { nome: "Férias Julho", inicio: "05/07/2026", fim: "31/07/2026", valor: 1800, minDiarias: 3 },
    { nome: "Temporada Alta", inicio: "15/12/2026", fim: "15/01/2027", valor: 2400, minDiarias: 4 },
  ],
  valorBaixa: 900,
  valorMedia: 1200,
  valorAlta: 1800,
  perguntasFrequentes: [
    { pergunta: "Tem Wi-Fi?", resposta: "Sim! Temos Wi-Fi de alta velocidade em toda a casa." },
    { pergunta: "Aceita cartão?", resposta: "Aceitamos PIX, transferência bancária e cartão de crédito (com taxa de 3%)." },
    { pergunta: "Como é o estacionamento?", resposta: "Temos garagem coberta para 3 carros." },
  ],
};

// ==============================
// DADOS DA Z-API
// (preencha com seus dados)
// ==============================
const ZAPI = {
  instanceId: process.env.ZAPI_INSTANCE_ID || "3F3B98610581F08E0CCC5264ACD813A3",
  token: process.env.ZAPI_TOKEN || "8E445CE6F63DDB6C34F1E5E2",
  clientToken: process.env.ZAPI_CLIENT_TOKEN || "F7cfada3a9d0048f2b5e9c67245bfe812S",
  meuNumero: process.env.MEU_NUMERO || "21980090609",
};

// Histórico de conversas por número
const historico = {};

// ==============================
// MONTA O PROMPT DO AGENTE
// ==============================
function montarPrompt() {
  return `Você é um assistente virtual simpático para locação da "${CONFIG.nomeCasa}", em ${CONFIG.localizacao}.

INFORMAÇÕES:
- ${CONFIG.descricao}
- Capacidade: ${CONFIG.capacidade}
- Check-in: ${CONFIG.checkIn} | Check-out: ${CONFIG.checkOut}
- Mínimo: ${CONFIG.minDiarias} diárias
- Contato do dono: ${CONFIG.contato}

REGRAS: ${CONFIG.regras}

PERÍODOS ESPECIAIS:
${CONFIG.periodos.map(p => `- ${p.nome} (${p.inicio} a ${p.fim}): R$${p.valor}/noite, mín. ${p.minDiarias} noites`).join("\n")}

PREÇOS REGULARES:
- Baixa: R$${CONFIG.valorBaixa}/noite | Média: R$${CONFIG.valorMedia}/noite | Alta: R$${CONFIG.valorAlta}/noite

PERGUNTAS FREQUENTES:
${CONFIG.perguntasFrequentes.map(f => `- "${f.pergunta}" → ${f.resposta}`).join("\n")}

INSTRUÇÕES:
1. Responda dúvidas sobre a casa, valores e disponibilidade
2. Quando o cliente quiser reservar, colete em sequência: nome completo, datas e número de pessoas
3. Após coletar os 3 dados, avise que vai encaminhar ao proprietário
4. Adicione ao final (invisível): [RESERVA: nome=X, entrada=X, saida=X, pessoas=X]
5. Respostas curtas, naturais, como WhatsApp. Português brasileiro. Emojis com moderação.`;
}

// ==============================
// CHAMA A IA (Claude)
// ==============================
async function chamarIA(telefone, novaMensagem) {
  if (!historico[telefone]) historico[telefone] = [];
  historico[telefone].push({ role: "user", content: novaMensagem });

  // Mantém só as últimas 20 mensagens pra não ficar pesado
  if (historico[telefone].length > 20) {
    historico[telefone] = historico[telefone].slice(-20);
  }

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: montarPrompt(),
      messages: historico[telefone],
    }),
  });

  const data = await resp.json();
  const resposta = data.content?.[0]?.text || "Desculpe, tive um problema. Tente novamente!";
  historico[telefone].push({ role: "assistant", content: resposta });
  return resposta;
}

// ==============================
// ENVIA MENSAGEM PELO WHATSAPP
// ==============================
async function enviarMensagem(telefone, texto) {
  const numero = telefone.replace(/\D/g, "").replace(/^55/, "");
  await fetch(`https://api.z-api.io/instances/${ZAPI.instanceId}/token/${ZAPI.token}/send-text`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Client-Token": ZAPI.clientToken },
    body: JSON.stringify({ phone: numero, message: texto }),
  });
}

// ==============================
// NOTIFICA O DONO
// ==============================
async function notificarDono(dados) {
  const msg = `🏠 *NOVA SOLICITAÇÃO DE RESERVA*\n\n👤 Nome: ${dados.nome}\n📅 Entrada: ${dados.entrada}\n📅 Saída: ${dados.saida}\n👥 Pessoas: ${dados.pessoas}\n\n_Enviado pelo seu agente virtual_ ✅`;
  await enviarMensagem(ZAPI.meuNumero, msg);
}

// ==============================
// WEBHOOK — recebe mensagens
// ==============================
app.post("/webhook", async (req, res) => {
  res.sendStatus(200); // responde rápido pra Z-API não reenviar

  try {
    const body = req.body;

    // Ignora mensagens enviadas pelo próprio bot
    if (body.fromMe) return;

    const telefone = body.phone;
    const texto = body.text?.message || body.text;
    if (!telefone || !texto) return;

    console.log(`📩 Mensagem de ${telefone}: ${texto}`);

    // Pede resposta pra IA
    const resposta = await chamarIA(telefone, texto);

    // Verifica se tem dados de reserva
    const match = resposta.match(/\[RESERVA:\s*nome=([^,]+),\s*entrada=([^,]+),\s*saida=([^,]+),\s*pessoas=([^\]]+)\]/i);
    if (match) {
      await notificarDono({ nome: match[1].trim(), entrada: match[2].trim(), saida: match[3].trim(), pessoas: match[4].trim() });
    }

    // Limpa a tag invisível antes de enviar pro cliente
    const respostaLimpa = resposta.replace(/\[RESERVA:[^\]]+\]/gi, "").trim();

    await enviarMensagem(telefone, respostaLimpa);
    console.log(`✅ Resposta enviada para ${telefone}`);

  } catch (err) {
    console.error("Erro:", err.message);
  }
});

// Rota de verificação
app.get("/", (req, res) => res.send("✅ Agente de temporada rodando!"));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Servidor rodando na porta ${PORT}`));
